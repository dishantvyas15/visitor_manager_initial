from django.db import models

class HostInfo(models.Model):
    class Meta:
        verbose_name_plural = 'HostInfo'
    h_name = models.CharField(max_length=50)
    h_contact = models.CharField(max_length=10)
    h_email = models.EmailField()
    h_login = models.DateTimeField(auto_now_add=True)
    h_logout = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.h_name

class VisitorInfo(models.Model):
    class Meta:
        verbose_name_plural = 'VisitorInfo'
    v_name = models.CharField(max_length=50)
    v_contact = models.CharField(max_length=10)
    v_email = models.EmailField()
    v_checkin = models.DateTimeField(auto_now_add=True)
    v_checkout = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.v_name
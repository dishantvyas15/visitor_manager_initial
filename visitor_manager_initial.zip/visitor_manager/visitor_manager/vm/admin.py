from django.contrib import admin
from vm.models import HostInfo, VisitorInfo

admin.site.register(HostInfo)
admin.site.register(VisitorInfo)
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import HostInfo, VisitorInfo
from django.contrib import messages

def index(request):
    return redirect('status')


def host_login(request):
    if request.method == 'POST':
        h_name = request.POST["h_name"]
        h_contact = request.POST["h_cc"] + request.POST["h_contact"]
        h_email = request.POST["h_email"]
        h_e = HostInfo(h_name=h_name, h_contact=h_contact, h_email=h_email)
        h_e.save()
        return redirect('status')
    else:
        return render(request, 'host_login.html')


def visitor_checkin(request):
    if request.method == 'POST':
        v_name = request.POST["v_name"]
        v_contact = request.POST["v_cc"] + request.POST["v_contact"]
        v_email = request.POST["v_email"]
        if VisitorInfo.objects.filter(v_email=v_email).exists():
            messages.info(request, 'Guest with this E-mail ID has already checked-in.')
            messages.info(request, 'Try using a different E-mail ID.')
            return redirect('visitor_checkin')
        else:
            v_e = VisitorInfo(v_name=v_name, v_contact=v_contact, v_email=v_email)
            v_e.save()
            return redirect('status')
    else:
        return render(request, 'visitor_checkin.html')


def status(request):
    contents = {
        'hosts' : HostInfo.objects.all(),
        'visitors' : VisitorInfo.objects.all()
    }
    return render(request, 'status.html', contents)


def visitor_checkout(request):
    if request.method == 'POST':
        checkout_email = request.POST['checkout_email']
        if VisitorInfo.objects.filter(v_email=checkout_email).exists():
            VisitorInfo.objects.get(v_email=checkout_email).save()
            return redirect('status')
        else:
            messages.info(request, 'No Guest has checked-in with this E-mail ID.')
            messages.info(request, 'Try using a different E-mail ID.')
            return redirect('visitor_checkout')
    else:
        return render(request, 'visitor_checkout.html')


def host_logout(request):
    if request.method == 'POST':
        checkout_email = request.POST['checkout_email']
        if HostInfo.objects.filter(h_email=checkout_email).exists():
            HostInfo.objects.get(h_email=checkout_email).save()
            return redirect('status')
        else:
            messages.info(request, 'No Host log-in found with this E-mail ID.')
            messages.info(request, 'Try using a different E-mail ID.')
            return redirect('host_logout')
    else:
        return render(request, 'host_logout.html')

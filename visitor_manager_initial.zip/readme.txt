---------------   Visitor Management Web Application (Initial Phase)   ---------------


 -->  'visitor_manager' is an application created as a part of 'MSTC Winter of Code 2.0', organised by MSTC, DA-IICT, Gandhinagar.
 -->  It is a full fledged web application developed using Python Django framework.
 -->  Front-end contents make good use of HTML and CSS.
 -->  The code for computational operations is written in Python.
 -->  The data at the back-end is efficiently managed in SQLite database.

 -->  Things to be covered in the Final Phase of this application:
        > Fabrication of front-end contents using Javascript.
	> Validation of data entered in form fields.
	> Prevention of 'Visitor Check-in' before 'Host Log-in'.
	> Other changes may be made as per the requirement.

 -->  Final Phase to be released soon.


 -->  Developed by:
	  Dishant Vyas
	  GitHub Profile:	https://github.com/dishantvyas15
	  Current Repository:	https://github.com/dishantvyas15/visitor_manager_initial